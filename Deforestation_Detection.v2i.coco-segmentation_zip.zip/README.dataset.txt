# Deforestation Detection > 2023-06-10 2:10pm
https://universe.roboflow.com/prasad-nr-070tz/deforestation-detection-ard9d

Provided by a Roboflow user
License: CC BY 4.0

